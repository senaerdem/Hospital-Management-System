
      const hospitalOptions = [
        { key: 'hospital1', text: 'City Hospital', value: 'City Hospital' },
        { key: 'hospital2', text: 'State General Hospital', value: 'State General Hospital' },
        { key: 'hospital3', text: 'Greenwood Medical Center', value: 'Greenwood Medical Center' },
        { key: 'hospital4', text: 'Sunrise Health Clinic', value: 'Sunrise Health Clinic' },
        { key: 'hospital5', text: 'Blue Ridge Hospital', value: 'Blue Ridge Hospital' },
        { key: 'hospital6', text: 'Altınbaş Hastanesi', value: 'Altınbaş Hastanesi' },
        { key: 'hospital7', text: 'Çapa Hastanesi', value: 'Çapa Hastanesi' },
        { key: 'hospital8', text: 'Gaziosmanpaşa Devlet Hastanesi', value: 'Gaziosmanpaşa Devlet Hastanesi' },
        { key: 'hospital9', text: 'Emerald Valley Hospital', value: 'Emerald Valley Hospital' },
        { key: 'hospital10', text: 'Golden Sands Medical Center', value: 'Golden Sands Medical Center' },
        { key: 'hospital11', text: 'Riverbank Health Facility', value: 'Riverbank Health Facility' },
        { key: 'hospital12', text: 'Silver Peak Clinic', value: 'Silver Peak Clinic' },
        { key: 'hospital13', text: 'Lakeside Medical Institute', value: 'Lakeside Medical Institute' },
        { key: 'hospital14', text: 'Mountain View General Hospital', value: 'Mountain View General Hospital' },
        { key: 'hospital15', text: 'Oakwood Medical Center', value: 'Oakwood Medical Center' },
        { key: 'hospital16', text: 'Starline Health Hospital', value: 'Starline Health Hospital' },
        { key: 'hospital17', text: 'Sunset Horizon Clinic', value: 'Sunset Horizon Clinic' },
        { key: 'hospital18', text: 'Crystal Waters Health Facility', value: 'Crystal Waters Health Facility' },
        { key: 'hospital19', text: 'Westfield Medical Center', value: 'Westfield Medical Center' },
        { key: 'hospital20', text: 'Northgate Health Institute', value: 'Northgate Health Institute' }
      ];
