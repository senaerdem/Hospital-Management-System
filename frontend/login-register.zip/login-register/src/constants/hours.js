      // Çalışma saatleri için dropdown seçenekleri - 08:00, 09:00, 10:00 gibi saat dilimleri
      const hours = [
        { key: '08:00', text: '08:00', value: '08:00' },
        { key: '09:00', text: '09:00', value: '09:00' },
        { key: '10:00', text: '10:00', value: '10:00' },
        { key: '11:00', text: '11:00', value: '11:00' },
        { key: '12:00', text: '12:00', value: '12:00' },
        { key: '13:00', text: '13:00', value: '13:00' },
        { key: '14:00', text: '14:00', value: '14:00' },
        { key: '15:00', text: '15:00', value: '15:00' },
        { key: '16:00', text: '16:00', value: '16:00' },
        { key: '17:00', text: '17:00', value: '17:00' },
        { key: '18:00', text: '18:00', value: '18:00' },
        { key: '19:00', text: '19:00', value: '19:00' },
      ];