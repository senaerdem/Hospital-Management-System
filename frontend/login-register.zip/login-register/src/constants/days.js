 // Çalışma günleri için dropdown seçenekleri
 const daysOfWeek = [
    { key: 'mon', text: 'Monday', value: 'Monday' },
    { key: 'tue', text: 'Tuesday', value: 'Tuesday' },
    { key: 'wed', text: 'Wednesday', value: 'Wednesday' },
    { key: 'thu', text: 'Thursday', value: 'Thursday' },
    { key: 'fri', text: 'Friday', value: 'Friday' },
    { key: 'sat', text: 'Saturday', value: 'Saturday' },
    { key: 'sun', text: 'Sunday', value: 'Sunday' },
  ];