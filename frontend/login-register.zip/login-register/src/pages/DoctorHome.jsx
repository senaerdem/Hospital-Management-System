import React, { useEffect, useState } from "react";
import {
  Container,
  Grid,
  Segment,
  List,
  Message,
  Dropdown,
  Icon,
  Tab,
  Form,
  Button,
} from "semantic-ui-react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
import stethoscope from "../assets/stethoscope.png";
import edit from "../assets/edit.png";
import timetable from "../assets/timetable.png";

export default function DoctorHome() {
  const [doctorName, setDoctorName] = useState(""); // Doktor adını tutmak için state
  const [doctorId, setDoctorId] = useState(""); // Doktor ID'sini tutmak için state
  const [appointments, setAppointments] = useState([]); // Doktorun randevularını tutmak için state
  const [loading, setLoading] = useState(false); // Yüklenme durumu için state
  const [doctorDetails, setDoctorDetails] = useState({
    hospital: "",
    specialization: "",
    workingDays: "",
    workingHours: "",
  }); // Doktor bilgilerini tutacak state

  const [hospitalOptions, setHospitalOptions] = useState([]); // Hastane seçeneklerini tutacak state
  const [specializationOptions, setSpecializationOptions] = useState([]); // Hastane seçeneklerini tutacak state

  // Çalışma günleri için dropdown seçenekleri
  const daysOfWeek = [
    { key: "mon", text: "Monday", value: "Monday" },
    { key: "tue", text: "Tuesday", value: "Tuesday" },
    { key: "wed", text: "Wednesday", value: "Wednesday" },
    { key: "thu", text: "Thursday", value: "Thursday" },
    { key: "fri", text: "Friday", value: "Friday" },
    { key: "sat", text: "Saturday", value: "Saturday" },
    { key: "sun", text: "Sunday", value: "Sunday" },
  ];

  // Çalışma saatleri için dropdown seçenekleri - 08:00, 09:00, 10:00 gibi saat dilimleri
  const hours = [
    { key: "08:00", text: "08:00", value: "08:00" },
    { key: "09:00", text: "09:00", value: "09:00" },
    { key: "10:00", text: "10:00", value: "10:00" },
    { key: "11:00", text: "11:00", value: "11:00" },
    { key: "12:00", text: "12:00", value: "12:00" },
    { key: "13:00", text: "13:00", value: "13:00" },
    { key: "14:00", text: "14:00", value: "14:00" },
    { key: "15:00", text: "15:00", value: "15:00" },
    { key: "16:00", text: "16:00", value: "16:00" },
    { key: "17:00", text: "17:00", value: "17:00" },
    { key: "18:00", text: "18:00", value: "18:00" },
    { key: "19:00", text: "19:00", value: "19:00" },
  ];

  useEffect(() => {
    // LocalStorage'dan giriş yapan doktorun bilgilerini alıyoruz
    const user = JSON.parse(localStorage.getItem("user"));
    if (user) {
      setDoctorName(`${user.firstName} ${user.lastName}`);
      setDoctorId(user.doctorId); // Doktor ID'sini alıyoruz
    }
  }, []);

  useEffect(() => {
    // Hastaneleri API'den çekiyoruz
    axios
      .get("http://localhost:8080/hospitals/all")
      .then((response) => {
        const options = response.data.map((hospital) => ({
          key: hospital.id,
          text: hospital.name,
          value: hospital.name,
        }));
        setHospitalOptions(options);
      })
      .catch((error) => {
        console.error("Hastaneler yüklenirken bir hata oluştu:", error);
        toast.error("Hastaneler yüklenirken bir hata oluştu.");
      });

    axios
      .get("http://localhost:8080/specializations/all")
      .then((response) => {
        const options = response.data.map((specialization) => ({
          key: specialization.id,
          text: specialization.name,
          value: specialization.name,
        }));
        setSpecializationOptions(options);
      })
      .catch((error) => {
        console.error("Uzmanlıklar yüklenirken bir hata oluştu:", error);
        toast.error("Uzmanlıklar yüklenirken bir hata oluştu.");
      });

    if (doctorId) {
      // Randevuları yüklemek için API çağrısı
      setLoading(true);
      axios
        .get(`http://localhost:8080/appointments/doctor/${doctorId}`)
        .then((response) => {
          setAppointments(response.data);
          setLoading(false);
        })
        .catch((error) => {
          console.error("Randevular yüklenirken bir hata oluştu:", error);
          toast.error("Randevular yüklenirken bir hata oluştu.");
          setLoading(false);
        });
    }
  }, [doctorId]);

  useEffect(() => {
    if (
      doctorId &&
      hospitalOptions.length > 0 &&
      specializationOptions.length > 0
    ) {
      // Doktor bilgilerini yükle
      axios
        .get(`http://localhost:8080/doctors/${doctorId}`)
        .then((response) => {
          const data = response.data;
          const hospitalOption = hospitalOptions.find(
            (option) => option.text === data.hospital
          );
          const specializationOption = specializationOptions.find(
            (option) => option.text === data.specialization
          );

          setDoctorDetails({
            hospital: hospitalOption ? hospitalOption.value : "",
            specialization: specializationOption
              ? specializationOption.value
              : "",
            workingDays: data.workingDays ? data.workingDays.split(",") : [],
            workingHours: data.workingHours ? data.workingHours.split(",") : [],
          });
        })
        .catch((error) => {
          console.error("Doktor bilgileri yüklenirken bir hata oluştu:", error);
        });
    }
  }, [doctorId, hospitalOptions, specializationOptions]);

  // Randevu durumları
  const statusOptions = [
    {
      key: "pending",
      text: (
        <span>
          <Icon name="hourglass half" style={{ color: "#FFA500" }} /> Pending
        </span>
      ),
      value: "PENDING",
    },
    {
      key: "confirmed",
      text: (
        <span>
          <Icon name="check circle" style={{ color: "#28a745" }} /> Confirmed
        </span>
      ),
      value: "CONFIRMED",
    },
    {
      key: "cancelled",
      text: (
        <span>
          <Icon name="times circle" style={{ color: "#dc3545" }} /> Cancelled
        </span>
      ),
      value: "CANCELLED",
    },
  ];

  const handleChange = (e, { name, value }) => {
    setDoctorDetails({
      ...doctorDetails,
      [name]: value,
    });
  };

  // Durum değişikliğini backend'e gönderme fonksiyonu
  const handleStatusChange = (appointmentId, newStatus) => {
    axios
      .put(
        `http://localhost:8080/appointments/update-status/${appointmentId}?status=${newStatus}`
      )
      .then((response) => {
        setAppointments(
          appointments.map((appointment) =>
            appointment.id === appointmentId
              ? { ...appointment, status: newStatus }
              : appointment
          )
        );
        toast.success("Randevu durumu başarıyla güncellendi!");
      })
      .catch((error) => {
        console.error("Randevu durumu güncellenirken bir hata oluştu:", error);
        toast.error("Randevu durumu güncellenirken bir hata oluştu.");
      });
  };

  const handleEditSubmit = () => {
    const updateData = {
      hospital: doctorDetails.hospital,
      specialization: doctorDetails.specialization,
      workingDays: doctorDetails.workingDays.join(","),
      workingHours: doctorDetails.workingHours.join(","),
    };

    axios
      .put(`http://localhost:8080/doctors/update/${doctorId}`, updateData)
      .then((response) => {
        toast.success("Doktor bilgileri başarıyla güncellendi!");
      })
      .catch((error) => {
        console.error(
          "Doktor bilgileri güncellenirken bir hata oluştu:",
          error.response ? error.response.data : error.message
        );
        toast.error("Doktor bilgileri güncellenirken bir hata oluştu.");
      });
  };

  // Tab options
  const panes = [
    {
      menuItem: "Appointments",
      render: () => (
        <Tab.Pane attached={false}>
          <h3 style={styles.header}>
            {" "}
            <img src={timetable} alt="Appointments" style={styles.icon} />{" "}
            Appointments
          </h3>
          {loading ? (
            <Message info>Randevular yükleniyor...</Message>
          ) : appointments.length > 0 ? (
            <List divided relaxed>
              {appointments.map((appointment) => {
                const { color, icon } = getStatusStyles(appointment.status); // Durum stilini al
                return (
                  <List.Item key={appointment.id} style={styles.listItem}>
                    <List.Content>
                      <List.Header>
                        {appointment.patient.user.firstName}{" "}
                        {appointment.patient.user.lastName}
                      </List.Header>
                      <List.Description>
                        Day: {appointment.day} | Time: {appointment.time}
                      </List.Description>

                      {/* Durum görüntüleme ve durum güncelleme */}
                      <Grid.Row columns={2} verticalAlign="middle">
                        <Grid.Column textAlign="right">
                          <Dropdown
                            fluid
                            selection
                            options={statusOptions}
                            value={appointment.status}
                            onChange={(e, { value }) =>
                              handleStatusChange(appointment.id, value)
                            }
                          />
                        </Grid.Column>
                      </Grid.Row>
                    </List.Content>
                  </List.Item>
                );
              })}
            </List>
          ) : (
            <Message info>No appointments available</Message>
          )}
        </Tab.Pane>
      ),
    },
    {
      menuItem: "Edit Profile",
      render: () => (
        <Tab.Pane>
          <h3 style={styles.header}>
            {" "}
            <img src={edit} alt="Appointments" style={styles.icon} /> Edit
            Profile
          </h3>
          <Form onSubmit={handleEditSubmit}>
            {/* Hastane Dropdown */}
            <Form.Field>
              <label>Hospital</label>
              <Dropdown
                fluid
                selection
                options={hospitalOptions}
                value={doctorDetails.hospital}
                onChange={(e, { value }) =>
                  setDoctorDetails({ ...doctorDetails, hospital: value })
                }
              />
            </Form.Field>

            {/* Uzmanlık Dropdown */}
            <Form.Field>
              <label>Specialization</label>
              <Dropdown
                fluid
                selection
                options={specializationOptions}
                value={doctorDetails.specialization}
                onChange={(e, { value }) =>
                  setDoctorDetails({ ...doctorDetails, specialization: value })
                }
              />
            </Form.Field>
            <Form.Field>
              <label>Working Days</label>
              <Dropdown
                fluid
                multiple
                selection
                options={daysOfWeek}
                value={doctorDetails.workingDays}
                onChange={(e, { value }) =>
                  setDoctorDetails({ ...doctorDetails, workingDays: value })
                }
              />
            </Form.Field>

            <Form.Field>
              <label>Working Hours</label>
              <Dropdown
                fluid
                multiple
                selection
                options={hours}
                value={doctorDetails.workingHours}
                onChange={(e, { value }) =>
                  setDoctorDetails({ ...doctorDetails, workingHours: value })
                }
              />
            </Form.Field>

            <Button type="submit" color="blue">
              Save Changes
            </Button>
          </Form>
        </Tab.Pane>
      ),
    },
  ];

  // Durum için renkli stil ve ikonlar
  const getStatusStyles = (status) => {
    switch (status) {
      case "PENDING":
        return { color: "#FFA500", icon: "hourglass half" };
      case "CONFIRMED":
        return { color: "#28a745", icon: "check circle" };
      case "CANCELLED":
        return { color: "#dc3545", icon: "times circle" };
      default:
        return { color: "#6c757d", icon: "question circle" };
    }
  };

  return (
    <Container style={styles.container}>
      <Segment raised>
        <Grid>
          <Grid.Row columns={2}>
            <Grid.Column>
              <h2>Doctor Dashboard</h2>
            </Grid.Column>
            <Grid.Column textAlign="right">
              <h3>
                Welcome, {doctorName}!{" "}
                <img
                  src={stethoscope}
                  alt="stethoscope logo"
                  style={styles.logo}
                />
              </h3>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </Segment>

      {/* Tab Component */}
      <Tab panes={panes} />

      {/* ToastContainer */}
      <ToastContainer
        position="bottom-center"
        autoClose={3000}
        hideProgressBar
        newestOnTop
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        className="toast-container"
      />
    </Container>
  );
}

const styles = {
  container: {
    marginTop: "2em",
    padding: "20px",
  },
  list: {
    marginTop: "20px",
  },
  listItem: {
    marginBottom: "15px",
    padding: "10px",
    borderRadius: "8px",
    backgroundColor: "#f9f9f9",
    boxShadow: "0 2px 10px rgba(0, 0, 0, 0.1)",
  },
  dropdown: {
    width: "150px",
    marginTop: "10px",
  },
  logo: {
    width: "40px", // Resmin boyutunu ayarlayın
    height: "40px", // Yüksekliği de ayarlayın
    marginRight: "10px", // Resim ile yazı arasına boşluk ekler
  },
  icon: {
    width: "45px", // Resmin genişliği
    height: "45px", // Resmin yüksekliği
    marginRight: "10px", // Resim ile yazı arasına boşluk ekler
  },
  header: {
    display: "flex", // Flex düzeni ile hizalama
    alignItems: "center", // Resim ve metni ortalar
  },
};
